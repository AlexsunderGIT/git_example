namespace ConsoleProject.NET.Contract;

public record UserAddDto(string Name, string Password);